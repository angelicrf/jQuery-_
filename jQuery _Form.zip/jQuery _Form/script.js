$(function(){
'use strict';
    
    
var $contact_Form = $("#my-form");
    
    $contact_Form.find(".group:nth-child(1)").click(function(){
    
       var validate= $("#input_One").val();
        console.log("go to this func" +$("#input_One").val());
        if (!validate){
            
     $contact_Form.find(".group:nth-child(1)").removeClass("confirm").addClass("error")
    .append("<p>There is an error</p>");
       
        }
        else{
           
           $contact_Form.find(".group:nth-child(1)").removeClass("error").addClass("confirm"); 
        }
        
    });
    
    $contact_Form.find(".group:nth-child(2)").click(function(){
        
       var re = /^[0-9-+]+$/;
       var validate_2 = re.test ($("#input_Two").val());
        
       
        if (!validate_2){
            
      $contact_Form.find(".group:nth-child(2)").removeClass("confirm").addClass("require")
    .append("<p>Required</p>");
       
        }
        else{
           
           $contact_Form.find(".group:nth-child(2)").removeClass("require").addClass("confirm"); 
        }
        
    });
   
    $contact_Form.find(".group:nth-child(3)").append("<p>Good Choice</p>");
    var $control_img = $("#my_Image");
    $control_img.click(function(){
        
         $control_img.fadeOut(1000);
        
    });
   
    
});