$(function() {
"use strict";
var $form =  $("#container");
	$("#anim")
    .on("click", function(el){
         
        el.preventDefault();
        console.log("Are you here?");
     
      $form.find("a").animate({
          'margin-left':'+=50',
          'height': '=40'
      },500,'easeInQuint',function(){
          $(this).fadeOut(4000);
      });
    
    	});
});