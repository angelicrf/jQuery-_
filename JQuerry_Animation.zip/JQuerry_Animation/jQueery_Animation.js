$(function() {
"use strict";

	var $flowers = $('#images');
	
	$flowers
    .find("a")
    	.colorbox({
    		'rel' : 'gallery',
			'transition' : 'fade',
			'speed' : 200,
			'opacity' : 0.5,
			'slideshow' : true,
			'slideshowSpeed' : 3000,
			'width' :350
    	});
});